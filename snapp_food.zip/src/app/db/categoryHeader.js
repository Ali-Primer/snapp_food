export const categories = [
    {
        "name": "رستوران",
        "image": 'https://cdn.snappfood.ir/uploads/images/review-app/icons/count/desktop_1_603508bf202d8_img_st_food.png'
    },
    {
        "name": "سوپر مارکت",
        "image": "https://cdn.snappfood.ir/uploads/images/review-app/icons/count/desktop_4_603508a14ab73_img_st_supermarket.png"
    },
    {
        "name": "کافه",
        "image": "https://cdn.snappfood.ir/uploads/images/review-app/icons/count/desktop_2_603508b330711_img_st_cafe.png"
    },
    {
        "name": "شیرینی",
        "image": "https://cdn.snappfood.ir/uploads/images/review-app/icons/count/desktop_3_603508a95b9be_img_st_sweet.png"
    },
    {
        "name": "نانوایی",
        "image": "https://cdn.snappfood.ir/uploads/images/review-app/icons/count/desktop_5_60350898c61b5_img_st_bakery.png"
    },
    {
        "name": "میوه",
        "image": "https://cdn.snappfood.ir/uploads/images/review-app/icons/count/desktop_6_6035088cbcde4_img_st_fruit.png"
    },
    {
        "name": "پروتئین",
        "image": "https://cdn.snappfood.ir/uploads/images/review-app/icons/count/desktop_11_603507afc9a32_img_st_meat.png"
    },
    {
        "name": "آبمیوه بستنی",
        "image": "https://cdn.snappfood.ir/uploads/images/review-app/icons/count/desktop_8_6035087b463a3_img_st_icecream.png"
    },
    {
        "name": "آجیل",
        "image": "https://cdn.snappfood.ir/uploads/images/review-app/icons/count/desktop_7_60350883d6e43_img_st_nut.png"
    },
    {
        "name": "سایر",
        "image": "https://cdn.snappfood.ir/uploads/images/review-app/icons/count/desktop_9_603b811b1d540_img_st_other2.png"
    }
]