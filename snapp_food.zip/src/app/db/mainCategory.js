export const MainCategories = [
    {
        "name" : "ایرانی",
        "image": "https://cdn.snappfood.ir/uploads/images/tags/website_image_irani_1.jpg"
    },
    {
        "name" : "فست فود",
        "image": "https://cdn.snappfood.ir/uploads/images/tags/website_image_fastfood_1.jpg"
    },
    {
        "name" : "کباب",
        "image": "https://cdn.snappfood.ir/uploads/images/tags/website_image_kebab_1.jpg"
    },
    {
        "name" : "پیتزا",
        "image": "https://cdn.snappfood.ir/uploads/images/tags/website_image_pizza_1.jpg"
    },
    {
        "name" : "برگر",
        "image": "https://cdn.snappfood.ir/uploads/images/tags/website_image_burger_1.jpg"
    },
    {
        "name" : "ساندویچ",
        "image": "https://cdn.snappfood.ir/uploads/images/tags/website_image_sandwich_1.jpg"
    },
    {
        "name" : "سوخاری",
        "image": "https://cdn.snappfood.ir/uploads/images/tags/website_image_sokhari_1.jpg"
    },
    {
        "name" : "پاستا",
        "image": "https://cdn.snappfood.ir/uploads/images/tags/website_image_italy_1.jpg"
    },
    {
        "name" : "سالاد",
        "image": "https://cdn.snappfood.ir/uploads/images/tags/website_image_salad_1.jpg"
    },
    {
        "name" : "دریایی",
        "image": "https://cdn.snappfood.ir/uploads/images/tags/website_image_seafood_1.jpg"
    },
    {
        "name" : "بین الملل",
        "image": "https://cdn.snappfood.ir/uploads/images/tags/website_image_asian_1.jpg"
    },
    {
        "name" : "گیلانی",
        "image": "https://cdn.snappfood.ir/uploads/images/tags/website_image_gilani_1.jpg"
    },
]