import classNames from "classnames";
import { IoSearch } from "react-icons/io5";

export const Search = () => (
    <>
        <div className="search_main">
            <input className="search_main_input" placeholder="جست و جو در اسنپ فود" type="text" />
            <IoSearch className={classNames('opened_searchBarButton', 'search_button')} />
        </div>
    </>
)