export const Cities = ({city}) => {
return(
    <div className="city">
        {city}
    </div>
)
}