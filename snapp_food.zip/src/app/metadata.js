export const metadata = {
    title: "snapp food",
    description: "the final project",
};